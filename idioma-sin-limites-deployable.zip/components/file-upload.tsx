"use client"

import type React from "react"

import { useState, useRef } from "react"
import { ref, uploadBytesResumable, getDownloadURL } from "firebase/storage"
import { storage } from "@/lib/firebase"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { useLanguage } from "@/app/context/language-context"

interface FileUploadProps {
  onFileUploaded?: (url: string, fileName: string) => void
  acceptedTypes?: string
  maxSizeMB?: number
  folder?: string
  className?: string
}

export default function FileUpload({
  onFileUploaded,
  acceptedTypes = ".pdf,.doc,.docx,.jpg,.jpeg,.png",
  maxSizeMB = 10,
  folder = "uploads",
  className = "",
}: FileUploadProps) {
  const [file, setFile] = useState<File | null>(null)
  const [uploading, setUploading] = useState(false)
  const [progress, setProgress] = useState(0)
  const [error, setError] = useState("")
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { t } = useLanguage()

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0]

      // Check file size
      if (selectedFile.size > maxSizeMB * 1024 * 1024) {
        setError(`${t("fileUploadError")}: ${t("maxFileSize")} ${maxSizeMB}MB`)
        return
      }

      setFile(selectedFile)
      setError("")
    }
  }

  const handleUpload = async () => {
    if (!file) return

    setUploading(true)
    setProgress(0)

    try {
      const storageRef = ref(storage, `${folder}/${Date.now()}_${file.name}`)
      const uploadTask = uploadBytesResumable(storageRef, file)

      uploadTask.on(
        "state_changed",
        (snapshot) => {
          const progress = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100)
          setProgress(progress)
        },
        (error) => {
          console.error("Upload error:", error)
          setError(`${t("fileUploadError")}: ${error.message}`)
          setUploading(false)
        },
        async () => {
          const downloadURL = await getDownloadURL(uploadTask.snapshot.ref)
          if (onFileUploaded) {
            onFileUploaded(downloadURL, file.name)
          }
          setUploading(false)
          setFile(null)
          if (fileInputRef.current) {
            fileInputRef.current.value = ""
          }
        },
      )
    } catch (error: any) {
      console.error("Upload error:", error)
      setError(`${t("fileUploadError")}: ${error.message}`)
      setUploading(false)
    }
  }

  return (
    <div className={`space-y-4 ${className}`}>
      <div className="flex items-center space-x-2">
        <input
          type="file"
          onChange={handleFileChange}
          accept={acceptedTypes}
          disabled={uploading}
          ref={fileInputRef}
          className="flex-1 text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
        />
        <Button onClick={handleUpload} disabled={!file || uploading}>
          {uploading ? `${progress}%` : t("uploadFile")}
        </Button>
      </div>

      {uploading && <Progress value={progress} className="h-2" />}

      {error && <p className="text-red-500 text-sm">{error}</p>}

      <p className="text-xs text-gray-500">
        {t("maxFileSize")}: {maxSizeMB}MB. {t("supportedFormats")}: {acceptedTypes.replace(/\./g, "")}
      </p>
    </div>
  )
}
