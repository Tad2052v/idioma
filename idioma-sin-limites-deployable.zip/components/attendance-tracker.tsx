"use client"

import { useState, useEffect } from "react"
import { ref, get, set, update } from "firebase/database"
import { database } from "@/lib/firebase"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useLanguage } from "@/app/context/language-context"

interface Student {
  id: string
  name: string
  email: string
}

interface AttendanceRecord {
  date: string
  status: "present" | "absent" | "late" | "excused"
}

interface AttendanceTrackerProps {
  classId: string
  courseId: string
  professorId: string
  className?: string
}

export default function AttendanceTracker({ classId, courseId, professorId, className = "" }: AttendanceTrackerProps) {
  const [students, setStudents] = useState<Student[]>([])
  const [attendance, setAttendance] = useState<Record<string, string>>({})
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [date, setDate] = useState<string>("")
  const [success, setSuccess] = useState("")
  const [error, setError] = useState("")
  const { t } = useLanguage()

  useEffect(() => {
    // Set today's date as default
    const today = new Date().toISOString().split("T")[0]
    setDate(today)

    const loadStudents = async () => {
      if (!database || !courseId) return

      try {
        // Get course data to find enrolled students
        const courseRef = ref(database, `cursos/${courseId}`)
        const courseSnapshot = await get(courseRef)

        if (!courseSnapshot.exists()) {
          setLoading(false)
          return
        }

        const courseData = courseSnapshot.val()
        const enrolledStudents = courseData.estudiantes || []

        if (enrolledStudents.length === 0) {
          setLoading(false)
          return
        }

        // Get student details
        const studentsList: Student[] = []
        const attendanceData: Record<string, string> = {}

        for (const studentId of enrolledStudents) {
          const studentRef = ref(database, `users/${studentId}`)
          const studentSnapshot = await get(studentRef)

          if (studentSnapshot.exists()) {
            const studentData = studentSnapshot.val()
            studentsList.push({
              id: studentId,
              name: studentData.nombre || studentData.email?.split("@")[0] || "Sin nombre",
              email: studentData.email || "Sin correo",
            })

            // Initialize attendance as 'present'
            attendanceData[studentId] = "present"
          }
        }

        // Check if attendance for today already exists
        const attendanceRef = ref(database, `attendance/${classId}/${today}`)
        const attendanceSnapshot = await get(attendanceRef)

        if (attendanceSnapshot.exists()) {
          const existingAttendance = attendanceSnapshot.val()
          Object.keys(existingAttendance).forEach((studentId) => {
            if (attendanceData[studentId]) {
              attendanceData[studentId] = existingAttendance[studentId].status
            }
          })
        }

        setStudents(studentsList)
        setAttendance(attendanceData)
      } catch (error) {
        console.error("Error loading students:", error)
        setError("Error al cargar estudiantes")
      } finally {
        setLoading(false)
      }
    }

    loadStudents()
  }, [courseId, classId])

  const handleAttendanceChange = (studentId: string, status: string) => {
    setAttendance((prev) => ({
      ...prev,
      [studentId]: status,
    }))
  }

  const saveAttendance = async () => {
    if (!database || !classId || !date) return

    setSaving(true)
    setSuccess("")
    setError("")

    try {
      const attendanceRef = ref(database, `attendance/${classId}/${date}`)

      // Format attendance data
      const attendanceData: Record<string, any> = {}
      Object.entries(attendance).forEach(([studentId, status]) => {
        attendanceData[studentId] = {
          status,
          recordedBy: professorId,
          timestamp: new Date().toISOString(),
        }
      })

      await set(attendanceRef, attendanceData)

      // Update class record to include this attendance date
      const classAttendanceDatesRef = ref(database, `clases/${classId}/attendanceDates`)
      const classAttendanceDatesSnapshot = await get(classAttendanceDatesRef)

      let attendanceDates = classAttendanceDatesSnapshot.exists() ? classAttendanceDatesSnapshot.val() : []

      if (!Array.isArray(attendanceDates)) {
        attendanceDates = []
      }

      if (!attendanceDates.includes(date)) {
        attendanceDates.push(date)
        await update(ref(database, `clases/${classId}`), {
          attendanceDates,
        })
      }

      setSuccess("Asistencia guardada correctamente")
    } catch (error) {
      console.error("Error saving attendance:", error)
      setError("Error al guardar la asistencia")
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return <div className="p-4 text-center">Cargando estudiantes...</div>
  }

  if (students.length === 0) {
    return (
      <Card className={className}>
        <CardHeader>
          <CardTitle>{t("attendance")}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-500 text-center">No hay estudiantes inscritos en este curso.</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle>{t("attendance")}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center space-x-4">
            <div className="w-full">
              <label className="block text-sm font-medium text-gray-700 mb-1">Fecha</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2"
              />
            </div>
          </div>

          {success && (
            <div className="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded">{success}</div>
          )}

          {error && <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded">{error}</div>}

          <div className="border rounded-lg overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Estudiante
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Estado
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {students.map((student) => (
                  <tr key={student.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{student.name}</div>
                      <div className="text-sm text-gray-500">{student.email}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <Select
                        value={attendance[student.id] || "present"}
                        onValueChange={(value) => handleAttendanceChange(student.id, value)}
                      >
                        <SelectTrigger className="w-[180px]">
                          <SelectValue placeholder="Estado" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="present">{t("present")}</SelectItem>
                          <SelectItem value="absent">{t("absent")}</SelectItem>
                          <SelectItem value="late">{t("late")}</SelectItem>
                          <SelectItem value="excused">{t("excused")}</SelectItem>
                        </SelectContent>
                      </Select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex justify-end">
            <Button onClick={saveAttendance} disabled={saving}>
              {saving ? "Guardando..." : t("markAttendance")}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
