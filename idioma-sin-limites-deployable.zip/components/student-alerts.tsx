"use client"

import { useState, useEffect } from "react"
import { ref, get, update, onValue } from "firebase/database"
import { database } from "@/lib/firebase"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useLanguage } from "@/app/context/language-context"

interface Alert {
  id: string
  title: string
  message: string
  date: string
  type: "info" | "warning" | "success" | "error"
  read?: boolean
  courseId?: string
  courseName?: string
}

interface StudentAlertsProps {
  userId: string
  limit?: number
  showAll?: boolean
  className?: string
}

export default function StudentAlerts({ userId, limit = 3, showAll = false, className = "" }: StudentAlertsProps) {
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [loading, setLoading] = useState(true)
  const { t } = useLanguage()

  useEffect(() => {
    if (!database || !userId) return

    const loadAlerts = async () => {
      try {
        // Get user data to find assigned courses
        const userRef = ref(database, `users/${userId}`)
        const userSnapshot = await get(userRef)

        if (!userSnapshot.exists()) {
          setLoading(false)
          return
        }

        const userData = userSnapshot.val()
        const userCourses = userData.curso ? (Array.isArray(userData.curso) ? userData.curso : [userData.curso]) : []

        // Subscribe to alerts
        const alertsRef = ref(database, "alerts")
        const unsubscribe = onValue(alertsRef, (snapshot) => {
          if (snapshot.exists()) {
            const alertsData = snapshot.val()
            const userAlerts: Alert[] = []

            Object.entries(alertsData).forEach(([id, data]: [string, any]) => {
              // Include global alerts and course-specific alerts for user's courses
              if (!data.courseId || (data.courseId && userCourses.includes(data.courseId))) {
                // Check if this alert has been read by this user
                const readByUsers = data.readByUsers || {}
                const isRead = readByUsers[userId] === true

                userAlerts.push({
                  id,
                  title: data.title,
                  message: data.message,
                  date: data.date,
                  type: data.type || "info",
                  read: isRead,
                  courseId: data.courseId,
                  courseName: data.courseName,
                })
              }
            })

            // Sort by date (newest first) and filter by read status if not showing all
            userAlerts.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())

            // Apply limit if not showing all
            const filteredAlerts = showAll ? userAlerts : userAlerts.slice(0, limit)

            setAlerts(filteredAlerts)
          } else {
            setAlerts([])
          }

          setLoading(false)
        })

        return () => unsubscribe()
      } catch (error) {
        console.error("Error loading alerts:", error)
        setLoading(false)
      }
    }

    loadAlerts()
  }, [userId, limit, showAll])

  const markAsRead = async (alertId: string) => {
    if (!database || !userId) return

    try {
      const alertRef = ref(database, `alerts/${alertId}/readByUsers/${userId}`)
      await update(alertRef, true)

      // Update local state
      setAlerts(alerts.map((alert) => (alert.id === alertId ? { ...alert, read: true } : alert)))
    } catch (error) {
      console.error("Error marking alert as read:", error)
    }
  }

  const getAlertTypeStyles = (type: string) => {
    switch (type) {
      case "warning":
        return "bg-yellow-100 text-yellow-800 border-yellow-300"
      case "success":
        return "bg-green-100 text-green-800 border-green-300"
      case "error":
        return "bg-red-100 text-red-800 border-red-300"
      case "info":
      default:
        return "bg-blue-100 text-blue-800 border-blue-300"
    }
  }

  if (loading) {
    return <div className="p-4 text-center">Cargando alertas...</div>
  }

  if (alerts.length === 0) {
    return (
      <Card className={className}>
        <CardHeader>
          <CardTitle>{t("alertsAndAnnouncements")}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-500 text-center">{t("noAlerts")}</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle>{t("alertsAndAnnouncements")}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {alerts.map((alert) => (
            <div
              key={alert.id}
              className={`p-4 border rounded-lg ${getAlertTypeStyles(alert.type)} ${!alert.read ? "border-l-4" : ""}`}
            >
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-medium">{alert.title}</h3>
                  {alert.courseName && (
                    <Badge variant="outline" className="mb-2">
                      {alert.courseName}
                    </Badge>
                  )}
                </div>
                {!alert.read && (
                  <Button variant="ghost" size="sm" onClick={() => markAsRead(alert.id)}>
                    {t("markAsRead")}
                  </Button>
                )}
              </div>
              <p className="text-sm mt-1">{alert.message}</p>
              <p className="text-xs mt-2 text-gray-500">{new Date(alert.date).toLocaleDateString()}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
