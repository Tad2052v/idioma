"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"

interface LanguageSwitcherProps {
  className?: string
}

export default function LanguageSwitcher({ className }: LanguageSwitcherProps) {
  const [language, setLanguage] = useState<"es" | "en">("es")
  const router = useRouter()

  useEffect(() => {
    // Get language from localStorage if available
    const storedLanguage = localStorage.getItem("language") as "es" | "en"
    if (storedLanguage) {
      setLanguage(storedLanguage)
    }
  }, [])

  const toggleLanguage = () => {
    const newLanguage = language === "es" ? "en" : "es"
    setLanguage(newLanguage)
    localStorage.setItem("language", newLanguage)
    // Force a refresh to update all components
    window.location.reload()
  }

  return (
    <Button onClick={toggleLanguage} variant="outline" size="sm" className={className}>
      {language === "es" ? "English" : "Español"}
    </Button>
  )
}
