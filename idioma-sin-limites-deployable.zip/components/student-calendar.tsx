"use client"

import { useState, useEffect } from "react"
import { Calendar, momentLocalizer } from "react-big-calendar"
import moment from "moment"
import "moment/locale/es"
import "moment/locale/en-gb"
import "react-big-calendar/lib/css/react-big-calendar.css"
import { ref, get } from "firebase/database"
import { database } from "@/lib/firebase"
import { useLanguage } from "@/app/context/language-context"

// Initialize localizer with moment
const localizer = momentLocalizer(moment)

interface CalendarEvent {
  id: string
  title: string
  start: Date
  end: Date
  allDay?: boolean
  resource?: any
  type: "class" | "task"
}

interface StudentCalendarProps {
  userId: string
  className?: string
}

export default function StudentCalendar({ userId, className = "" }: StudentCalendarProps) {
  const [events, setEvents] = useState<CalendarEvent[]>([])
  const [loading, setLoading] = useState(true)
  const { language, t } = useLanguage()

  // Set moment locale based on current language
  useEffect(() => {
    moment.locale(language === "es" ? "es" : "en-gb")
  }, [language])

  // Load classes and tasks
  useEffect(() => {
    const loadEvents = async () => {
      if (!database || !userId) return

      try {
        // Get user data to find assigned courses
        const userRef = ref(database, `users/${userId}`)
        const userSnapshot = await get(userRef)

        if (!userSnapshot.exists()) {
          setLoading(false)
          return
        }

        const userData = userSnapshot.val()
        const userCourses = userData.curso ? (Array.isArray(userData.curso) ? userData.curso : [userData.curso]) : []

        const calendarEvents: CalendarEvent[] = []

        // Load classes for user's courses
        if (userCourses.length > 0) {
          const classesRef = ref(database, "clases")
          const classesSnapshot = await get(classesRef)

          if (classesSnapshot.exists()) {
            const classesData = classesSnapshot.val()

            Object.entries(classesData).forEach(([id, data]: [string, any]) => {
              if (userCourses.includes(data.cursoAsignado)) {
                // Parse class time and create event
                if (data.hora) {
                  const [hours, minutes] = data.hora.split(":").map(Number)

                  // Create a date for today with the class time
                  const startDate = new Date()
                  startDate.setHours(hours, minutes, 0, 0)

                  // End time is 1 hour after start
                  const endDate = new Date(startDate)
                  endDate.setHours(endDate.getHours() + 1)

                  calendarEvents.push({
                    id: id,
                    title: data.nombre,
                    start: startDate,
                    end: endDate,
                    type: "class",
                  })
                }
              }
            })
          }
        }

        // Load tasks for user's courses
        if (userCourses.length > 0) {
          const tasksRef = ref(database, "tareas")
          const tasksSnapshot = await get(tasksRef)

          if (tasksSnapshot.exists()) {
            const tasksData = tasksSnapshot.val()

            Object.entries(tasksData).forEach(([id, data]: [string, any]) => {
              if (userCourses.includes(data.cursoAsignado) && data.fechaEntrega) {
                // Parse due date
                const dueDate = new Date(data.fechaEntrega)

                // Set time to end of day
                const endDate = new Date(dueDate)
                endDate.setHours(23, 59, 59, 999)

                calendarEvents.push({
                  id: id,
                  title: data.titulo,
                  start: dueDate,
                  end: endDate,
                  allDay: true,
                  type: "task",
                })
              }
            })
          }
        }

        setEvents(calendarEvents)
      } catch (error) {
        console.error("Error loading calendar events:", error)
      } finally {
        setLoading(false)
      }
    }

    loadEvents()
  }, [userId])

  // Custom event styling
  const eventStyleGetter = (event: CalendarEvent) => {
    const style = {
      backgroundColor: event.type === "class" ? "#3b82f6" : "#10b981",
      borderRadius: "4px",
      opacity: 0.8,
      color: "white",
      border: "0px",
      display: "block",
    }
    return { style }
  }

  // Translations for calendar
  const messages = {
    allDay: language === "es" ? "Todo el día" : "All day",
    previous: language === "es" ? "Anterior" : "Previous",
    next: language === "es" ? "Siguiente" : "Next",
    today: language === "es" ? "Hoy" : "Today",
    month: language === "es" ? "Mes" : "Month",
    week: language === "es" ? "Semana" : "Week",
    day: language === "es" ? "Día" : "Day",
    agenda: language === "es" ? "Agenda" : "Agenda",
    date: language === "es" ? "Fecha" : "Date",
    time: language === "es" ? "Hora" : "Time",
    event: language === "es" ? "Evento" : "Event",
    noEventsInRange: language === "es" ? "No hay eventos en este rango" : "No events in this range",
  }

  if (loading) {
    return <div className="flex justify-center p-8">Cargando calendario...</div>
  }

  return (
    <div className={`${className}`}>
      <div className="mb-4 flex justify-between items-center">
        <h2 className="text-xl font-semibold">{t("calendar")}</h2>
        <div className="flex space-x-2 text-sm">
          <div className="flex items-center">
            <div className="w-3 h-3 bg-blue-500 rounded-full mr-1"></div>
            <span>{language === "es" ? "Clases" : "Classes"}</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-green-500 rounded-full mr-1"></div>
            <span>{language === "es" ? "Tareas" : "Tasks"}</span>
          </div>
        </div>
      </div>
      <div className="h-[500px]">
        <Calendar
          localizer={localizer}
          events={events}
          startAccessor="start"
          endAccessor="end"
          style={{ height: "100%" }}
          eventPropGetter={eventStyleGetter}
          messages={messages}
        />
      </div>
    </div>
  )
}
