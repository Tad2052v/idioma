// Import the functions you need from the SDKs you need
import { initializeApp, getApps } from "firebase/app"
import { getAuth } from "firebase/auth"
import { getDatabase } from "firebase/database"
import { getStorage } from "firebase/storage"

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
  databaseURL: process.env.NEXT_PUBLIC_FIREBASE_DATABASE_URL,
}

// Check if Firebase config is valid
const isFirebaseConfigValid = () => {
  return (
    firebaseConfig.apiKey &&
    firebaseConfig.apiKey !== "demo-api-key" &&
    firebaseConfig.apiKey !== "undefined" &&
    firebaseConfig.authDomain &&
    firebaseConfig.projectId &&
    firebaseConfig.databaseURL
  )
}

// Initialize Firebase
let app
let auth
let database
let storage
let firebaseInitialized = false

try {
  if (isFirebaseConfigValid() && !getApps().length) {
    app = initializeApp(firebaseConfig)
    auth = getAuth(app)
    database = getDatabase(app)
    storage = getStorage(app)
    firebaseInitialized = true
    console.log("Firebase initialized successfully")
  } else if (getApps().length > 0) {
    app = getApps()[0]
    auth = getAuth(app)
    database = getDatabase(app)
    storage = getStorage(app)
    firebaseInitialized = true
    console.log("Firebase already initialized")
  } else {
    console.log("Firebase configuration is not valid, using development mode")
    firebaseInitialized = false
    auth = null
    database = null
    storage = null
  }
} catch (error) {
  console.error("Error initializing Firebase:", error)
  firebaseInitialized = false
  auth = null
  database = null
  storage = null
}

export { auth, database, storage, firebaseInitialized }
