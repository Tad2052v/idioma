"use client"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { ref, get, onValue, update } from "firebase/database"
import { database, auth } from "@/lib/firebase"
import Link from "next/link"
import { onAuthStateChanged } from "firebase/auth"
import LanguageSwitcher from "@/components/language-switcher"
import { useLanguage } from "@/app/context/language-context"
import FileUpload from "@/components/file-upload"

interface Tarea {
  id: string
  titulo: string
  descripcion: string
  fechaEntrega: string
  claseAsignada: string
  claseNombre: string
  cursoAsignado: string
  entregado: boolean
  entregadoPor?: string[]
  archivos?: Record<
    string,
    {
      url: string
      nombre: string
      subidoPor: string
      fechaSubida: string
    }
  >
}

export default function DetalleTarea() {
  const [tarea, setTarea] = useState<Tarea | null>(null)
  const [loading, setLoading] = useState(true)
  const [userName, setUserName] = useState("")
  const [userId, setUserId] = useState("")
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const [submitting, setSubmitting] = useState(false)
  const router = useRouter()
  const params = useParams()
  const tareaId = params.id as string
  const { t } = useLanguage()

  // Verificar autenticación
  useEffect(() => {
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "estudiante") {
            router.push(`/${userData.role}`)
          }
          setUserName(userData.email?.split("@")[0] || "Estudiante")
          setUserId(userData.uid || "")
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const userRef = ref(database, `users/${user.uid}`)
            const snapshot = await get(userRef)
            const userData = snapshot.val()
            const role = userData?.role

            setUserName(user.email?.split("@")[0] || "Estudiante")
            setUserId(user.uid)

            if (role !== "estudiante") {
              router.push(`/${role || "login"}`)
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  // Cargar datos de la tarea
  useEffect(() => {
    if (!database || !tareaId || !userId) return

    const tareaRef = ref(database, `tareas/${tareaId}`)
    const unsubscribe = onValue(tareaRef, async (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val()

        // Obtener nombre de la clase
        let claseNombre = "Clase sin nombre"
        if (data.claseAsignada) {
          const claseRef = ref(database, `clases/${data.claseAsignada}`)
          const claseSnapshot = await get(claseRef)
          if (claseSnapshot.exists()) {
            claseNombre = claseSnapshot.val().nombre || "Clase sin nombre"
          }
        }

        setTarea({
          id: tareaId,
          titulo: data.titulo || "Sin título",
          descripcion: data.descripcion || "Sin descripción",
          fechaEntrega: data.fechaEntrega || "Sin fecha",
          claseAsignada: data.claseAsignada || "",
          claseNombre,
          cursoAsignado: data.cursoAsignado || "",
          entregado: data.entregadoPor && data.entregadoPor.includes(userId),
          entregadoPor: data.entregadoPor || [],
          archivos: data.archivos || {},
        })
      } else {
        setError("La tarea no existe")
      }
      setLoading(false)
    })

    return () => unsubscribe()
  }, [tareaId, userId, database])

  const handleFileUploaded = async (url: string, fileName: string) => {
    if (!database || !tareaId || !userId) return

    setSubmitting(true)
    setError("")
    setSuccess("")

    try {
      // Actualizar la tarea con el archivo subido
      const tareaRef = ref(database, `tareas/${tareaId}`)
      const tareaSnapshot = await get(tareaRef)

      if (!tareaSnapshot.exists()) {
        setError("La tarea no existe")
        setSubmitting(false)
        return
      }

      const tareaData = tareaSnapshot.val()

      // Crear o actualizar la lista de archivos
      const archivos = tareaData.archivos || {}
      const fileId = Date.now().toString()

      archivos[fileId] = {
        url,
        nombre: fileName,
        subidoPor: userId,
        fechaSubida: new Date().toISOString(),
      }

      // Actualizar la lista de estudiantes que han entregado
      let entregadoPor = tareaData.entregadoPor || []
      if (!Array.isArray(entregadoPor)) {
        entregadoPor = []
      }

      if (!entregadoPor.includes(userId)) {
        entregadoPor.push(userId)
      }

      // Actualizar la tarea en la base de datos
      await update(tareaRef, {
        archivos,
        entregadoPor,
      })

      setSuccess("Tarea entregada correctamente")

      // Actualizar el estado local
      if (tarea) {
        setTarea({
          ...tarea,
          entregado: true,
          entregadoPor,
          archivos,
        })
      }
    } catch (error) {
      console.error("Error al entregar tarea:", error)
      setError("Error al entregar la tarea")
    } finally {
      setSubmitting(false)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("user")
    if (auth) {
      auth.signOut()
    }
    router.push("/login")
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  if (!tarea) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="bg-white p-8 rounded-lg shadow-md">
          <p className="text-red-500 mb-4">{error || "La tarea no existe"}</p>
          <Link href="/estudiante/tareas">
            <button className="bg-blue-600 text-white px-4 py-2 rounded-lg">Volver a tareas</button>
          </Link>
        </div>
      </div>
    )
  }

  // Calcular estado de la tarea
  const fechaEntrega = new Date(tarea.fechaEntrega)
  const hoy = new Date()
  const diasRestantes = Math.ceil((fechaEntrega.getTime() - hoy.getTime()) / (1000 * 60 * 60 * 24))

  let estadoTarea = "pending"
  let estadoColor = "bg-yellow-100 text-yellow-800"

  if (tarea.entregado) {
    estadoTarea = "submitted"
    estadoColor = "bg-green-100 text-green-800"
  } else if (fechaEntrega < hoy) {
    estadoTarea = "overdue"
    estadoColor = "bg-red-100 text-red-800"
  } else if (diasRestantes <= 2) {
    estadoTarea = "dueSoon"
    estadoColor = "bg-orange-100 text-orange-800"
  } else {
    estadoTarea = "inProgress"
    estadoColor = "bg-blue-100 text-blue-800"
  }

  // Obtener archivos subidos por el estudiante
  const misArchivos = Object.entries(tarea.archivos || {})
    .filter(([_, archivo]) => archivo.subidoPor === userId)
    .map(([id, archivo]) => ({
      id,
      ...archivo,
      fechaSubida: new Date(archivo.fechaSubida).toLocaleDateString(),
    }))

  return (
    <div className="min-h-screen bg-white text-gray-800">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">{t("taskDetails")}</h1>
        <div className="flex items-center space-x-4">
          <LanguageSwitcher className="mr-2" />
          <span>
            {t("hello")}, {userName}
          </span>
          <Link href="/estudiante/tareas">
            <button className="bg-blue-600 text-white px-4 py-1 rounded-lg text-sm font-medium hover:bg-blue-500">
              {t("back")}
            </button>
          </Link>
          <button
            onClick={handleLogout}
            className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100"
          >
            {t("logout")}
          </button>
        </div>
      </header>

      <div className="p-8">
        <div className="bg-white p-6 rounded-xl shadow-md">
          <div className="mb-6">
            <h2 className="text-2xl font-bold mb-2">{tarea.titulo}</h2>
            <div className="flex flex-wrap gap-2 mb-4">
              <span className={`px-3 py-1 rounded-full text-sm ${estadoColor}`}>{t(estadoTarea as any)}</span>
              <span className="px-3 py-1 rounded-full bg-gray-100 text-gray-800 text-sm">
                {t("dueDate")}: {new Date(tarea.fechaEntrega).toLocaleDateString()}
              </span>
              {tarea.claseNombre && (
                <span className="px-3 py-1 rounded-full bg-blue-50 text-blue-800 text-sm">
                  {t("assignedClass")}: {tarea.claseNombre}
                </span>
              )}
            </div>

            <div className="bg-gray-50 p-4 rounded-lg mb-6">
              <h3 className="font-medium mb-2">{t("taskDescription")}</h3>
              <p className="whitespace-pre-line">{tarea.descripcion}</p>
            </div>

            {success && (
              <div className="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded">{success}</div>
            )}

            {error && <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded">{error}</div>}

            <div className="mb-6">
              <h3 className="font-medium mb-2">{t("submitTask")}</h3>
              <FileUpload onFileUploaded={handleFileUploaded} folder={`tareas/${tareaId}`} maxSizeMB={100} />
            </div>

            {misArchivos.length > 0 && (
              <div>
                <h3 className="font-medium mb-2">Archivos entregados</h3>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <ul className="divide-y divide-gray-200">
                    {misArchivos.map((archivo) => (
                      <li key={archivo.id} className="py-3 flex justify-between items-center">
                        <div>
                          <p className="font-medium">{archivo.nombre}</p>
                          <p className="text-sm text-gray-500">Subido el {archivo.fechaSubida}</p>
                        </div>
                        <a
                          href={archivo.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:text-blue-800"
                        >
                          Ver archivo
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
