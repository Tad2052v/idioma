"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ref, get, onValue } from "firebase/database"
import { database, auth } from "@/lib/firebase"
import Link from "next/link"
import { onAuthStateChanged } from "firebase/auth"
import LanguageSwitcher from "@/components/language-switcher"
import { useLanguage } from "@/app/context/language-context"

interface Tarea {
  id: string
  titulo: string
  descripcion: string
  fechaEntrega: string
  claseAsignada: string
  claseNombre: string
  cursoAsignado: string
  entregado: boolean
}

export default function TareasEstudiante() {
  const [tareas, setTareas] = useState<Tarea[]>([])
  const [loading, setLoading] = useState(true)
  const [userName, setUserName] = useState("")
  const [userId, setUserId] = useState("")
  const [userCourses, setUserCourses] = useState<string[]>([])
  const router = useRouter()
  const { t } = useLanguage()

  // Verificar autenticación
  useEffect(() => {
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "estudiante") {
            router.push(`/${userData.role}`)
          }
          setUserName(userData.email?.split("@")[0] || "Estudiante")
          setUserId(userData.uid || "")
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const userRef = ref(database, `users/${user.uid}`)
            const snapshot = await get(userRef)
            const userData = snapshot.val()
            const role = userData?.role

            setUserName(user.email?.split("@")[0] || "Estudiante")
            setUserId(user.uid)

            // Obtener los cursos del usuario
            const userCourses = userData.curso
              ? Array.isArray(userData.curso)
                ? userData.curso
                : [userData.curso]
              : []
            setUserCourses(userCourses)

            if (role !== "estudiante") {
              router.push(`/${role || "login"}`)
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  // Cargar tareas
  useEffect(() => {
    if (!database || !userId || userCourses.length === 0) return

    const tareasRef = ref(database, "tareas")
    const unsubscribe = onValue(tareasRef, async (snapshot) => {
      if (snapshot.exists()) {
        const tareasData = snapshot.val()
        const tareasArray: Tarea[] = []

        // Obtener todas las clases para tener sus nombres
        const clasesRef = ref(database, "clases")
        const clasesSnapshot = await get(clasesRef)
        const clasesData = clasesSnapshot.exists() ? clasesSnapshot.val() : {}

        // Filtrar tareas por curso del estudiante
        for (const [id, data] of Object.entries<any>(tareasData)) {
          if (userCourses.includes(data.cursoAsignado)) {
            // Obtener nombre de la clase
            let claseNombre = "Clase sin nombre"
            if (data.claseAsignada && clasesData[data.claseAsignada]) {
              claseNombre = clasesData[data.claseAsignada].nombre || "Clase sin nombre"
            }

            tareasArray.push({
              id,
              titulo: data.titulo || "Sin título",
              descripcion: data.descripcion || "Sin descripción",
              fechaEntrega: data.fechaEntrega || "Sin fecha",
              claseAsignada: data.claseAsignada || "",
              claseNombre,
              cursoAsignado: data.cursoAsignado || "",
              entregado: data.entregadoPor && Array.isArray(data.entregadoPor) && data.entregadoPor.includes(userId),
            })
          }
        }

        // Ordenar por fecha de entrega (más cercanas primero)
        tareasArray.sort((a, b) => {
          return new Date(a.fechaEntrega).getTime() - new Date(b.fechaEntrega).getTime()
        })

        setTareas(tareasArray)
      } else {
        setTareas([])
      }
      setLoading(false)
    })

    return () => unsubscribe()
  }, [userId, userCourses, database])

  const handleLogout = () => {
    localStorage.removeItem("user")
    if (auth) {
      auth.signOut()
    }
    router.push("/login")
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white text-gray-800">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">{t("tasks")}</h1>
        <div className="flex items-center space-x-4">
          <LanguageSwitcher className="mr-2" />
          <span>
            {t("hello")}, {userName}
          </span>
          <Link href="/estudiante">
            <button className="bg-blue-600 text-white px-4 py-1 rounded-lg text-sm font-medium hover:bg-blue-500">
              {t("dashboard")}
            </button>
          </Link>
          <button
            onClick={handleLogout}
            className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100"
          >
            {t("logout")}
          </button>
        </div>
      </header>

      <div className="p-8">
        <div className="bg-white p-6 rounded-xl shadow-md">
          <h2 className="text-2xl font-semibold mb-6">{t("pendingTasks")}</h2>

          {tareas.length === 0 ? (
            <div className="text-center py-8 bg-gray-50 rounded-lg">
              <p className="text-gray-500">{t("noTasksDue")}</p>
            </div>
          ) : (
            <div className="grid gap-4">
              {tareas.map((tarea) => {
                // Calcular estado de la tarea
                const fechaEntrega = new Date(tarea.fechaEntrega)
                const hoy = new Date()
                const diasRestantes = Math.ceil((fechaEntrega.getTime() - hoy.getTime()) / (1000 * 60 * 60 * 24))

                let estadoTarea = "pending"
                let estadoColor = "bg-yellow-100 text-yellow-800"

                if (tarea.entregado) {
                  estadoTarea = "submitted"
                  estadoColor = "bg-green-100 text-green-800"
                } else if (fechaEntrega < hoy) {
                  estadoTarea = "overdue"
                  estadoColor = "bg-red-100 text-red-800"
                } else if (diasRestantes <= 2) {
                  estadoTarea = "dueSoon"
                  estadoColor = "bg-orange-100 text-orange-800"
                } else {
                  estadoTarea = "inProgress"
                  estadoColor = "bg-blue-100 text-blue-800"
                }

                return (
                  <Link href={`/estudiante/tareas/${tarea.id}`} key={tarea.id}>
                    <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-medium text-lg">{tarea.titulo}</h3>
                          <p className="text-sm text-gray-500 mb-2">
                            {tarea.claseNombre} • {t("dueDate")}: {new Date(tarea.fechaEntrega).toLocaleDateString()}
                          </p>
                          <p className="text-sm line-clamp-2">{tarea.descripcion}</p>
                        </div>
                        <span className={`px-3 py-1 rounded-full text-sm ${estadoColor}`}>{t(estadoTarea as any)}</span>
                      </div>
                    </div>
                  </Link>
                )
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
