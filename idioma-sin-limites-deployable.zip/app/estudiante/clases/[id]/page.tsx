"use client"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { ref, get } from "firebase/database"
import { database, auth } from "@/lib/firebase"
import Link from "next/link"
import { onAuthStateChanged } from "firebase/auth"
import LanguageSwitcher from "@/components/language-switcher"
import { useLanguage } from "@/app/context/language-context"

interface Clase {
  id: string
  nombre: string
  descripcion: string
  hora: string
  nivel: string
  cursoAsignado: string
  cursoNombre: string
  videoUrl?: string
  archivos?: Record<string, { url: string; nombre: string }>
}

export default function DetalleClase() {
  const [clase, setClase] = useState<Clase | null>(null)
  const [loading, setLoading] = useState(true)
  const [userName, setUserName] = useState("")
  const [userId, setUserId] = useState("")
  const [error, setError] = useState("")
  const router = useRouter()
  const params = useParams()
  const claseId = params.id as string
  const { t } = useLanguage()

  // Verificar autenticación
  useEffect(() => {
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "estudiante") {
            router.push(`/${userData.role}`)
          }
          setUserName(userData.email?.split("@")[0] || "Estudiante")
          setUserId(userData.uid || "")
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const userRef = ref(database, `users/${user.uid}`)
            const snapshot = await get(userRef)
            const userData = snapshot.val()
            const role = userData?.role

            setUserName(user.email?.split("@")[0] || "Estudiante")
            setUserId(user.uid)

            if (role !== "estudiante") {
              router.push(`/${role || "login"}`)
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  // Cargar datos de la clase
  useEffect(() => {
    if (!database || !claseId) return

    const loadClase = async () => {
      try {
        const claseRef = ref(database, `clases/${claseId}`)
        const snapshot = await get(claseRef)

        if (snapshot.exists()) {
          const data = snapshot.val()

          // Obtener nombre del curso
          let cursoNombre = "Curso sin nombre"
          if (data.cursoAsignado) {
            const cursoRef = ref(database, `cursos/${data.cursoAsignado}`)
            const cursoSnapshot = await get(cursoRef)
            if (cursoSnapshot.exists()) {
              cursoNombre = cursoSnapshot.val().nombre || "Curso sin nombre"
            }
          }

          setClase({
            id: claseId,
            nombre: data.nombre || "Sin nombre",
            descripcion: data.descripcion || "Sin descripción",
            hora: data.hora || "Sin hora",
            nivel: data.nivel || "Sin nivel",
            cursoAsignado: data.cursoAsignado || "",
            cursoNombre,
            videoUrl: data.videoUrl,
            archivos: data.archivos || {},
          })
        } else {
          setError("La clase no existe")
        }
      } catch (error) {
        console.error("Error al cargar clase:", error)
        setError("Error al cargar la clase")
      } finally {
        setLoading(false)
      }
    }

    loadClase()
  }, [claseId, database])

  const handleLogout = () => {
    localStorage.removeItem("user")
    if (auth) {
      auth.signOut()
    }
    router.push("/login")
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  if (!clase) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="bg-white p-8 rounded-lg shadow-md">
          <p className="text-red-500 mb-4">{error || "La clase no existe"}</p>
          <Link href="/estudiante/clases">
            <button className="bg-blue-600 text-white px-4 py-2 rounded-lg">Volver a clases</button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white text-gray-800">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">{t("className")}</h1>
        <div className="flex items-center space-x-4">
          <LanguageSwitcher className="mr-2" />
          <span>
            {t("hello")}, {userName}
          </span>
          <Link href="/estudiante/clases">
            <button className="bg-blue-600 text-white px-4 py-1 rounded-lg text-sm font-medium hover:bg-blue-500">
              {t("back")}
            </button>
          </Link>
          <button
            onClick={handleLogout}
            className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100"
          >
            {t("logout")}
          </button>
        </div>
      </header>

      <div className="p-8">
        <div className="bg-white p-6 rounded-xl shadow-md">
          <div className="mb-6">
            <h2 className="text-2xl font-bold mb-2">{clase.nombre}</h2>
            <div className="flex flex-wrap gap-2 mb-4">
              <span className="px-3 py-1 rounded-full bg-blue-100 text-blue-800 text-sm">
                {t("classTime")}: {clase.hora}
              </span>
              <span className="px-3 py-1 rounded-full bg-purple-100 text-purple-800 text-sm">
                {t("classLevel")}: {clase.nivel}
              </span>
              <span className="px-3 py-1 rounded-full bg-gray-100 text-gray-800 text-sm">{clase.cursoNombre}</span>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg mb-6">
              <h3 className="font-medium mb-2">{t("classDescription")}</h3>
              <p className="whitespace-pre-line">{clase.descripcion}</p>
            </div>

            {clase.videoUrl && (
              <div className="mb-6">
                <h3 className="font-medium mb-2">Video de la clase</h3>
                <div className="aspect-w-16 aspect-h-9">
                  <iframe
                    src={clase.videoUrl}
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="w-full h-full rounded-lg"
                  ></iframe>
                </div>
              </div>
            )}

            {clase.archivos && Object.keys(clase.archivos).length > 0 && (
              <div>
                <h3 className="font-medium mb-2">Material de clase</h3>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <ul className="divide-y divide-gray-200">
                    {Object.entries(clase.archivos).map(([id, archivo]) => (
                      <li key={id} className="py-3 flex justify-between items-center">
                        <p className="font-medium">{archivo.nombre}</p>
                        <a
                          href={archivo.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:text-blue-800"
                        >
                          Descargar
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
