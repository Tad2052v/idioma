"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ref, get, onValue } from "firebase/database"
import { database, auth } from "@/lib/firebase"
import Link from "next/link"
import { onAuthStateChanged } from "firebase/auth"
import LanguageSwitcher from "@/components/language-switcher"
import { useLanguage } from "@/app/context/language-context"

interface Clase {
  id: string
  nombre: string
  descripcion: string
  hora: string
  nivel: string
  cursoAsignado: string
  cursoNombre: string
  videoUrl?: string
}

export default function ClasesEstudiante() {
  const [clases, setClases] = useState<Clase[]>([])
  const [loading, setLoading] = useState(true)
  const [userName, setUserName] = useState("")
  const [userId, setUserId] = useState("")
  const [userCourses, setUserCourses] = useState<string[]>([])
  const router = useRouter()
  const { t } = useLanguage()

  // Verificar autenticación
  useEffect(() => {
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "estudiante") {
            router.push(`/${userData.role}`)
          }
          setUserName(userData.email?.split("@")[0] || "Estudiante")
          setUserId(userData.uid || "")
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const userRef = ref(database, `users/${user.uid}`)
            const snapshot = await get(userRef)
            const userData = snapshot.val()
            const role = userData?.role

            setUserName(user.email?.split("@")[0] || "Estudiante")
            setUserId(user.uid)

            // Obtener los cursos del usuario
            const userCourses = userData.curso
              ? Array.isArray(userData.curso)
                ? userData.curso
                : [userData.curso]
              : []
            setUserCourses(userCourses)

            if (role !== "estudiante") {
              router.push(`/${role || "login"}`)
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  // Cargar clases
  useEffect(() => {
    if (!database || !userId || userCourses.length === 0) return

    const clasesRef = ref(database, "clases")
    const unsubscribe = onValue(clasesRef, async (snapshot) => {
      if (snapshot.exists()) {
        const clasesData = snapshot.val()
        const clasesArray: Clase[] = []

        // Obtener todos los cursos para tener sus nombres
        const cursosRef = ref(database, "cursos")
        const cursosSnapshot = await get(cursosRef)
        const cursosData = cursosSnapshot.exists() ? cursosSnapshot.val() : {}

        // Filtrar clases por curso del estudiante
        for (const [id, data] of Object.entries<any>(clasesData)) {
          if (userCourses.includes(data.cursoAsignado)) {
            // Obtener nombre del curso
            let cursoNombre = "Curso sin nombre"
            if (data.cursoAsignado && cursosData[data.cursoAsignado]) {
              cursoNombre = cursosData[data.cursoAsignado].nombre || "Curso sin nombre"
            }

            clasesArray.push({
              id,
              nombre: data.nombre || "Sin nombre",
              descripcion: data.descripcion || "Sin descripción",
              hora: data.hora || "Sin hora",
              nivel: data.nivel || "Sin nivel",
              cursoAsignado: data.cursoAsignado || "",
              cursoNombre,
              videoUrl: data.videoUrl,
            })
          }
        }

        // Ordenar por hora
        clasesArray.sort((a, b) => {
          return a.hora.localeCompare(b.hora)
        })

        setClases(clasesArray)
      } else {
        setClases([])
      }
      setLoading(false)
    })

    return () => unsubscribe()
  }, [userId, userCourses, database])

  const handleLogout = () => {
    localStorage.removeItem("user")
    if (auth) {
      auth.signOut()
    }
    router.push("/login")
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white text-gray-800">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">{t("classes")}</h1>
        <div className="flex items-center space-x-4">
          <LanguageSwitcher className="mr-2" />
          <span>
            {t("hello")}, {userName}
          </span>
          <Link href="/estudiante">
            <button className="bg-blue-600 text-white px-4 py-1 rounded-lg text-sm font-medium hover:bg-blue-500">
              {t("dashboard")}
            </button>
          </Link>
          <button
            onClick={handleLogout}
            className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100"
          >
            {t("logout")}
          </button>
        </div>
      </header>

      <div className="p-8">
        <div className="bg-white p-6 rounded-xl shadow-md">
          <h2 className="text-2xl font-semibold mb-6">{t("assignedClasses")}</h2>

          {clases.length === 0 ? (
            <div className="text-center py-8 bg-gray-50 rounded-lg">
              <p className="text-gray-500">{t("noClassesAvailable")}</p>
              <p className="text-gray-500 mt-2">{t("classesWillAppear")}</p>
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {clases.map((clase) => (
                <Link href={`/estudiante/clases/${clase.id}`} key={clase.id}>
                  <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer h-full flex flex-col">
                    <h3 className="font-medium text-lg">{clase.nombre}</h3>
                    <p className="text-sm text-gray-500 mb-2">
                      {clase.cursoNombre} • {t("classLevel")}: {clase.nivel}
                    </p>
                    <p className="text-sm mb-2">{clase.descripcion}</p>
                    <div className="mt-auto pt-2">
                      <span className="inline-block bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs">
                        {t("classTime")}: {clase.hora}
                      </span>
                    </div>
                    {clase.videoUrl && (
                      <div className="mt-2">
                        <span className="inline-block bg-green-100 text-green-800 px-2 py-1 rounded text-xs">
                          Video disponible
                        </span>
                      </div>
                    )}
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
