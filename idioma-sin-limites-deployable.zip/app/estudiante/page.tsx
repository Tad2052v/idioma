"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { onAuthStateChanged } from "firebase/auth"
import { ref, get } from "firebase/database"
import { auth, database } from "@/lib/firebase"
import LanguageSwitcher from "@/components/language-switcher"
import { useLanguage } from "@/app/context/language-context"
import StudentAlerts from "@/components/student-alerts"

export default function EstudiantePanel() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [userName, setUserName] = useState("")
  const [userId, setUserId] = useState("")
  const { t, language } = useLanguage()

  useEffect(() => {
    // Verificar autenticación y rol
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "estudiante") {
            router.push(`/${userData.role}`)
          }
          setUserName(userData.email?.split("@")[0] || "Estudiante")
          setUserId(userData.uid || "")
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const snapshot = await get(ref(database, `users/${user.uid}`))
            const userData = snapshot.val()
            const role = userData?.role

            setUserName(user.email?.split("@")[0] || "Estudiante")
            setUserId(user.uid)

            if (role !== "estudiante") {
              router.push(`/${role || "login"}`)
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("user")
    if (auth) {
      auth.signOut()
    }
    router.push("/login")
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white text-gray-800">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">{t("studentPortal")}</h1>
        <div className="flex items-center space-x-4">
          <LanguageSwitcher className="mr-2" />
          <span>
            {t("hello")}, {userName}
          </span>
          <button
            onClick={handleLogout}
            className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100"
          >
            {t("logout")}
          </button>
        </div>
      </header>

      <div className="p-8">
        <div className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">{t("myLearning")}</h2>
          <div className="grid md:grid-cols-3 gap-4">
            <Link href="/estudiante/clases">
              <div className="bg-blue-50 p-6 rounded-xl shadow hover:shadow-md transition-shadow border border-blue-100">
                <h3 className="text-lg font-medium text-blue-700 mb-2">{t("assignedClasses")}</h3>
                <p className="text-gray-600 text-sm">
                  {language === "es"
                    ? "Accede a tus clases y material de estudio"
                    : "Access your classes and study materials"}
                </p>
              </div>
            </Link>

            <Link href="/estudiante/tareas">
              <div className="bg-green-50 p-6 rounded-xl shadow hover:shadow-md transition-shadow border border-green-100">
                <h3 className="text-lg font-medium text-green-700 mb-2">{t("pendingTasks")}</h3>
                <p className="text-gray-600 text-sm">
                  {language === "es"
                    ? "Revisa y entrega tus tareas asignadas"
                    : "Review and submit your assigned tasks"}
                </p>
              </div>
            </Link>

            <Link href="/estudiante/alertas">
              <div className="bg-purple-50 p-6 rounded-xl shadow hover:shadow-md transition-shadow border border-purple-100">
                <h3 className="text-lg font-medium text-purple-700 mb-2">{t("viewAlerts")}</h3>
                <p className="text-gray-600 text-sm">
                  {language === "es"
                    ? "Mantente al día con los anuncios importantes"
                    : "Stay up to date with important announcements"}
                </p>
              </div>
            </Link>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h2 className="text-2xl font-semibold mb-4">{t("upcomingClasses")}</h2>
            <div className="bg-gray-50 p-6 rounded-xl border border-gray-200">
              <p className="text-gray-500 italic">{t("noClassesToday")}</p>
              <Link href="/estudiante/calendario">
                <button className="mt-4 text-blue-600 hover:text-blue-800">{t("viewFullCalendar")}</button>
              </Link>
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-semibold mb-4">{t("pendingAssignments")}</h2>
            <div className="bg-gray-50 p-6 rounded-xl border border-gray-200">
              <p className="text-gray-500 italic">{t("noTasksDue")}</p>
              <Link href="/estudiante/tareas">
                <button className="mt-4 text-blue-600 hover:text-blue-800">{t("viewAllTasks")}</button>
              </Link>
            </div>
          </div>
        </div>

        {/* Alertas y notificaciones */}
        <div className="mt-8">
          <StudentAlerts userId={userId} />
        </div>
      </div>
    </div>
  )
}
