"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { onAuthStateChanged } from "firebase/auth"
import { ref, get } from "firebase/database"
import { auth, database } from "@/lib/firebase"
import Link from "next/link"
import LanguageSwitcher from "@/components/language-switcher"
import { useLanguage } from "@/app/context/language-context"

export default function ProfesorPanel() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [userName, setUserName] = useState("")
  const [userId, setUserId] = useState("")
  const [clases, setClases] = useState<any[]>([])
  const [tareas, setTareas] = useState<any[]>([])
  const { t } = useLanguage()

  useEffect(() => {
    // Verificar autenticación y rol
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "profesor") {
            router.push(`/${userData.role}`)
          }
          setUserName(userData.email?.split("@")[0] || "Profesor")
          setUserId(userData.uid || "")
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const snapshot = await get(ref(database, `users/${user.uid}`))
            const userData = snapshot.val()
            const role = userData?.role

            setUserName(user.email?.split("@")[0] || "Profesor")
            setUserId(user.uid)

            if (role !== "profesor") {
              router.push(`/${role || "login"}`)
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  // Cargar clases y tareas del profesor
  useEffect(() => {
    if (!database || !userId) return

    const loadData = async () => {
      try {
        // Cargar clases
        const clasesRef = ref(database, "clases")
        const clasesSnapshot = await get(clasesRef)

        if (clasesSnapshot.exists()) {
          const clasesData = clasesSnapshot.val()
          const clasesArray = Object.entries(clasesData)
            .filter(([_, data]: [string, any]) => data.profesorId === userId)
            .map(([id, data]: [string, any]) => ({
              id,
              nombre: data.nombre,
              hora: data.hora,
              nivel: data.nivel,
              cursoAsignado: data.cursoAsignado,
            }))
            .slice(0, 3) // Solo mostrar las 3 primeras

          setClases(clasesArray)
        }

        // Cargar tareas
        const tareasRef = ref(database, "tareas")
        const tareasSnapshot = await get(tareasRef)

        if (tareasSnapshot.exists()) {
          const tareasData = tareasSnapshot.val()
          const tareasArray = Object.entries(tareasData)
            .filter(([_, data]: [string, any]) => data.profesorId === userId)
            .map(([id, data]: [string, any]) => ({
              id,
              titulo: data.titulo,
              fechaEntrega: data.fechaEntrega,
              entregadoPor: data.entregadoPor ? (Array.isArray(data.entregadoPor) ? data.entregadoPor.length : 1) : 0,
            }))
            .slice(0, 3) // Solo mostrar las 3 primeras

          setTareas(tareasArray)
        }
      } catch (error) {
        console.error("Error al cargar datos:", error)
      }
    }

    loadData()
  }, [userId, database])

  const handleLogout = () => {
    localStorage.removeItem("user")
    if (auth) {
      auth.signOut()
    }
    router.push("/login")
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white text-gray-800">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">{t("teacherDashboard")}</h1>
        <div className="flex items-center space-x-4">
          <LanguageSwitcher className="mr-2" />
          <span>
            {t("hello")}, {userName}
          </span>
          <button
            onClick={handleLogout}
            className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100"
          >
            {t("logout")}
          </button>
        </div>
      </header>

      <div className="p-8">
        <div className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">{t("teacherDashboard")}</h2>
          <div className="grid md:grid-cols-3 gap-4">
            <Link href="/profesor/clases">
              <div className="bg-blue-50 p-6 rounded-xl shadow hover:shadow-md transition-shadow border border-blue-100">
                <h3 className="text-lg font-medium text-blue-700 mb-2">{t("uploadClass")}</h3>
                <p className="text-gray-600 text-sm">Sube y administra tus clases</p>
              </div>
            </Link>

            <Link href="/profesor/tareas">
              <div className="bg-green-50 p-6 rounded-xl shadow hover:shadow-md transition-shadow border border-green-100">
                <h3 className="text-lg font-medium text-green-700 mb-2">{t("assignTask")}</h3>
                <p className="text-gray-600 text-sm">Crea y revisa tareas para tus estudiantes</p>
              </div>
            </Link>

            <Link href="/profesor/asistencia">
              <div className="bg-purple-50 p-6 rounded-xl shadow hover:shadow-md transition-shadow border border-purple-100">
                <h3 className="text-lg font-medium text-purple-700 mb-2">{t("registerAttendance")}</h3>
                <p className="text-gray-600 text-sm">Registra la asistencia de tus estudiantes</p>
              </div>
            </Link>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h2 className="text-2xl font-semibold mb-4">{t("myClasses")}</h2>
            <div className="bg-gray-50 p-6 rounded-xl border border-gray-200">
              {clases.length === 0 ? (
                <p className="text-gray-500 italic">{t("noClassesScheduled")}</p>
              ) : (
                <div className="space-y-4">
                  {clases.map((clase) => (
                    <div key={clase.id} className="bg-white p-4 rounded-lg shadow-sm">
                      <h3 className="font-medium">{clase.nombre}</h3>
                      <p className="text-sm text-gray-500">
                        Hora: {clase.hora} • Nivel: {clase.nivel}
                      </p>
                    </div>
                  ))}
                  <Link href="/profesor/clases">
                    <button className="mt-2 text-blue-600 hover:text-blue-800">Ver todas las clases</button>
                  </Link>
                </div>
              )}
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-semibold mb-4">{t("taskReview")}</h2>
            <div className="bg-gray-50 p-6 rounded-xl border border-gray-200">
              {tareas.length === 0 ? (
                <p className="text-gray-500 italic">{t("noTasksToReview")}</p>
              ) : (
                <div className="space-y-4">
                  {tareas.map((tarea) => (
                    <div key={tarea.id} className="bg-white p-4 rounded-lg shadow-sm">
                      <h3 className="font-medium">{tarea.titulo}</h3>
                      <p className="text-sm text-gray-500">
                        Fecha de entrega: {new Date(tarea.fechaEntrega).toLocaleDateString()} • Entregas:{" "}
                        {tarea.entregadoPor}
                      </p>
                    </div>
                  ))}
                  <Link href="/profesor/tareas">
                    <button className="mt-2 text-blue-600 hover:text-blue-800">Ver todas las tareas</button>
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
