"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { onAuthStateChanged } from "firebase/auth"
import { ref, get } from "firebase/database"
import { auth, database } from "@/lib/firebase"
import Link from "next/link"
import LanguageSwitcher from "@/components/language-switcher"
import { useLanguage } from "@/app/context/language-context"
import AttendanceTracker from "@/components/attendance-tracker"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Clase {
  id: string
  nombre: string
  cursoAsignado: string
  cursoNombre: string
}

export default function AsistenciaProfesor() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [userName, setUserName] = useState("")
  const [userId, setUserId] = useState("")
  const [clases, setClases] = useState<Clase[]>([])
  const [selectedClase, setSelectedClase] = useState<string>("")
  const [selectedCurso, setSelectedCurso] = useState<string>("")
  const { t } = useLanguage()

  useEffect(() => {
    // Verificar autenticación y rol
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "profesor") {
            router.push(`/${userData.role}`)
          }
          setUserName(userData.email?.split("@")[0] || "Profesor")
          setUserId(userData.uid || "")
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const snapshot = await get(ref(database, `users/${user.uid}`))
            const userData = snapshot.val()
            const role = userData?.role

            setUserName(user.email?.split("@")[0] || "Profesor")
            setUserId(user.uid)

            if (role !== "profesor") {
              router.push(`/${role || "login"}`)
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  // Cargar clases del profesor
  useEffect(() => {
    if (!database || !userId) return

    const loadClases = async () => {
      try {
        // Cargar clases
        const clasesRef = ref(database, "clases")
        const clasesSnapshot = await get(clasesRef)

        if (clasesSnapshot.exists()) {
          const clasesData = clasesSnapshot.val()

          // Obtener todos los cursos para tener sus nombres
          const cursosRef = ref(database, "cursos")
          const cursosSnapshot = await get(cursosRef)
          const cursosData = cursosSnapshot.exists() ? cursosSnapshot.val() : {}

          const clasesArray: Clase[] = []

          Object.entries(clasesData).forEach(([id, data]: [string, any]) => {
            if (data.profesorId === userId) {
              // Obtener nombre del curso
              let cursoNombre = "Curso sin nombre"
              if (data.cursoAsignado && cursosData[data.cursoAsignado]) {
                cursoNombre = cursosData[data.cursoAsignado].nombre || "Curso sin nombre"
              }

              clasesArray.push({
                id,
                nombre: data.nombre || "Sin nombre",
                cursoAsignado: data.cursoAsignado || "",
                cursoNombre,
              })
            }
          })

          setClases(clasesArray)

          // Seleccionar la primera clase por defecto
          if (clasesArray.length > 0) {
            setSelectedClase(clasesArray[0].id)
            setSelectedCurso(clasesArray[0].cursoAsignado)
          }
        }
      } catch (error) {
        console.error("Error al cargar clases:", error)
      } finally {
        setLoading(false)
      }
    }

    loadClases()
  }, [userId, database])

  const handleClaseChange = (claseId: string) => {
    setSelectedClase(claseId)
    const clase = clases.find((c) => c.id === claseId)
    if (clase) {
      setSelectedCurso(clase.cursoAsignado)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("user")
    if (auth) {
      auth.signOut()
    }
    router.push("/login")
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white text-gray-800">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">{t("registerAttendance")}</h1>
        <div className="flex items-center space-x-4">
          <LanguageSwitcher className="mr-2" />
          <span>
            {t("hello")}, {userName}
          </span>
          <Link href="/profesor">
            <button className="bg-blue-600 text-white px-4 py-1 rounded-lg text-sm font-medium hover:bg-blue-500">
              {t("dashboard")}
            </button>
          </Link>
          <button
            onClick={handleLogout}
            className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100"
          >
            {t("logout")}
          </button>
        </div>
      </header>

      <div className="p-8">
        <div className="bg-white p-6 rounded-xl shadow-md">
          <h2 className="text-2xl font-semibold mb-6">{t("attendance")}</h2>

          {clases.length === 0 ? (
            <div className="text-center py-8 bg-gray-50 rounded-lg">
              <p className="text-gray-500">No tienes clases asignadas para registrar asistencia.</p>
              <Link href="/profesor/clases">
                <button className="mt-4 text-blue-600 hover:text-blue-800">Crear una clase</button>
              </Link>
            </div>
          ) : (
            <div>
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-1">Selecciona una clase</label>
                <Select value={selectedClase} onValueChange={handleClaseChange}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Selecciona una clase" />
                  </SelectTrigger>
                  <SelectContent>
                    {clases.map((clase) => (
                      <SelectItem key={clase.id} value={clase.id}>
                        {clase.nombre} - {clase.cursoNombre}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedClase && selectedCurso && (
                <AttendanceTracker classId={selectedClase} courseId={selectedCurso} professorId={userId} />
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
