"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/app/context/auth-context"
import { useLanguage } from "@/app/context/language-context"
import LanguageSwitcher from "@/components/language-switcher"
import { firebaseInitialized } from "@/lib/firebase"

export default function Login() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const { login } = useAuth()
  const router = useRouter()
  const { t } = useLanguage()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    try {
      const result = await login(email, password)
      if (result.success) {
        // Redirect based on role (handled in useEffect of AuthProvider)
        router.push("/estudiante")
      } else {
        setError(result.error || "Error al iniciar sesión")
      }
    } catch (error: any) {
      setError(error.message || "Error al iniciar sesión")
    } finally {
      setLoading(false)
    }
  }

  const setDemoCredentials = (type: string) => {
    if (type === "estudiante") {
      setEmail("estudiante@example.com")
      setPassword("password123")
    } else if (type === "profesor") {
      setEmail("profesor@example.com")
      setPassword("password123")
    } else if (type === "admin") {
      setEmail("admin@example.com")
      setPassword("password123")
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="absolute top-4 right-4">
        <LanguageSwitcher />
      </div>
      <div className="bg-white p-8 rounded-lg shadow-md w-96">
        <h1 className="text-2xl font-bold mb-6 text-center">Idioma Sin Límites</h1>
        <h2 className="text-xl font-medium mb-6 text-center">{t("login")}</h2>

        {error && <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4">{error}</div>}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700">
              Email
            </label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-gray-700">
              Password
            </label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
          >
            {loading ? "Cargando..." : t("login")}
          </button>
        </form>

        {!firebaseInitialized && (
          <div className="mt-6">
            <p className="text-sm text-gray-600 mb-2 text-center">
              Modo desarrollo: Selecciona un usuario de demostración
            </p>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => setDemoCredentials("estudiante")}
                className="py-1 px-2 text-xs bg-blue-100 text-blue-700 rounded hover:bg-blue-200"
              >
                Estudiante
              </button>
              <button
                onClick={() => setDemoCredentials("profesor")}
                className="py-1 px-2 text-xs bg-green-100 text-green-700 rounded hover:bg-green-200"
              >
                Profesor
              </button>
              <button
                onClick={() => setDemoCredentials("admin")}
                className="py-1 px-2 text-xs bg-purple-100 text-purple-700 rounded hover:bg-purple-200"
              >
                Admin
              </button>
            </div>
          </div>
        )}

        <div className="mt-6 text-center">
          <p className="text-xs text-gray-500">
            {firebaseInitialized ? "Firebase inicializado correctamente" : "Ejecutando en modo desarrollo sin Firebase"}
          </p>
        </div>
      </div>
    </div>
  )
}
