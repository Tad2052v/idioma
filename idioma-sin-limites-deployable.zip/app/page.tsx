"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/app/context/auth-context"

export default function Home() {
  const { user, loading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!loading) {
      if (user) {
        // Redirigir según el rol
        if (user.role) {
          router.push(`/${user.role}`)
        } else {
          router.push("/estudiante") // Default role
        }
      } else {
        router.push("/login")
      }
    }
  }, [user, loading, router])

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <p className="text-xl">Cargando...</p>
    </div>
  )
}
