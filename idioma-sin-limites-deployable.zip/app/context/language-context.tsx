"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

// Definir las traducciones
export const translations = {
  es: {
    // Común
    welcome: "Bienvenido",
    login: "Iniciar sesión",
    logout: "Cerrar sesión",
    dashboard: "Panel principal",
    profile: "Perfil",
    save: "Guardar",
    cancel: "Cancelar",
    submit: "Enviar",
    delete: "Eliminar",
    edit: "Editar",
    back: "Volver",

    // Navegación
    home: "Inicio",
    courses: "Cursos",
    tasks: "Tareas",
    classes: "Clases",
    videos: "Videos",
    alerts: "Alertas",

    // Estudiantes
    myLearning: "Mi Aprendizaje",
    assignedClasses: "Clases asignadas",
    pendingTasks: "Tareas pendientes",
    viewAlerts: "Ver alertas y anuncios",
    upcomingClasses: "Próximas Clases",
    pendingAssignments: "Tareas Pendientes",
    noClassesToday: "No hay clases programadas para hoy.",
    viewFullCalendar: "Ver calendario completo",
    noTasksDue: "No hay tareas pendientes por entregar.",
    viewAllTasks: "Ver todas las tareas",
    studentPortal: "Portal del Estudiante",
    hello: "Hola",

    // Tareas
    taskTitle: "Título de la tarea",
    taskDescription: "Descripción de la tarea",
    dueDate: "Fecha de entrega",
    assignedClass: "Clase asignada",
    taskStatus: "Estado de la tarea",
    submitted: "Entregada",
    pending: "Pendiente",
    overdue: "Vencida",
    dueSoon: "Próxima a vencer",
    inProgress: "En plazo",
    submitTask: "Entregar tarea",
    taskDetails: "Detalles de la tarea",

    // Clases
    className: "Nombre de la clase",
    classDescription: "Descripción de la clase",
    classTime: "Hora de la clase",
    classLevel: "Nivel",
    joinClass: "Unirse a la clase",
    noClassesAvailable: "No hay clases disponibles actualmente.",
    classesWillAppear: "Las clases programadas aparecerán aquí.",

    // Asistencia
    attendance: "Asistencia",
    present: "Presente",
    absent: "Ausente",
    late: "Tarde",
    excused: "Justificado",
    markAttendance: "Registrar asistencia",
    attendanceHistory: "Historial de asistencia",

    // Alertas
    alertsAndAnnouncements: "Alertas y anuncios",
    noAlerts: "No hay alertas o anuncios nuevos.",
    markAsRead: "Marcar como leído",

    // Cursos
    courseDetails: "Detalles del curso",
    enrolledStudents: "Estudiantes inscritos",
    courseLevel: "Nivel del curso",
    courseCapacity: "Capacidad del curso",
    enrollInCourse: "Inscribirse en el curso",
    unenrollFromCourse: "Cancelar inscripción",
    availableCourses: "Cursos disponibles",
    myCourses: "Mis cursos",

    // Archivos
    uploadFile: "Subir archivo",
    selectFile: "Seleccionar archivo",
    fileUploaded: "Archivo subido correctamente",
    fileUploadError: "Error al subir el archivo",
    maxFileSize: "Tamaño máximo del archivo",
    supportedFormats: "Formatos soportados",

    // Calendario
    calendar: "Calendario",
    today: "Hoy",
    month: "Mes",
    week: "Semana",
    day: "Día",

    // Errores
    error: "Error",
    pageNotFound: "Página no encontrada",
    unauthorized: "No autorizado",
    sessionExpired: "Sesión expirada",
    tryAgain: "Intentar de nuevo",

    // Profesor
    teacherDashboard: "Panel del Profesor",
    uploadClass: "Subir clase",
    assignTask: "Asignar tarea",
    registerAttendance: "Registrar asistencia",
    myClasses: "Mis Clases",
    taskReview: "Revisión de tareas",
    noClassesScheduled: "No hay clases programadas.",
    noTasksToReview: "No hay tareas pendientes por revisar.",
  },
  en: {
    // Common
    welcome: "Welcome",
    login: "Login",
    logout: "Logout",
    dashboard: "Dashboard",
    profile: "Profile",
    save: "Save",
    cancel: "Cancel",
    submit: "Submit",
    delete: "Delete",
    edit: "Edit",
    back: "Back",

    // Navigation
    home: "Home",
    courses: "Courses",
    tasks: "Tasks",
    classes: "Classes",
    videos: "Videos",
    alerts: "Alerts",

    // Students
    myLearning: "My Learning",
    assignedClasses: "Assigned Classes",
    pendingTasks: "Pending Tasks",
    viewAlerts: "View alerts and announcements",
    upcomingClasses: "Upcoming Classes",
    pendingAssignments: "Pending Assignments",
    noClassesToday: "No classes scheduled for today.",
    viewFullCalendar: "View full calendar",
    noTasksDue: "No pending tasks to submit.",
    viewAllTasks: "View all tasks",
    studentPortal: "Student Portal",
    hello: "Hello",

    // Tasks
    taskTitle: "Task Title",
    taskDescription: "Task Description",
    dueDate: "Due Date",
    assignedClass: "Assigned Class",
    taskStatus: "Task Status",
    submitted: "Submitted",
    pending: "Pending",
    overdue: "Overdue",
    dueSoon: "Due Soon",
    inProgress: "In Progress",
    submitTask: "Submit Task",
    taskDetails: "Task Details",

    // Classes
    className: "Class Name",
    classDescription: "Class Description",
    classTime: "Class Time",
    classLevel: "Level",
    joinClass: "Join Class",
    noClassesAvailable: "No classes available at the moment.",
    classesWillAppear: "Scheduled classes will appear here.",

    // Attendance
    attendance: "Attendance",
    present: "Present",
    absent: "Absent",
    late: "Late",
    excused: "Excused",
    markAttendance: "Mark Attendance",
    attendanceHistory: "Attendance History",

    // Alerts
    alertsAndAnnouncements: "Alerts and Announcements",
    noAlerts: "No new alerts or announcements.",
    markAsRead: "Mark as Read",

    // Courses
    courseDetails: "Course Details",
    enrolledStudents: "Enrolled Students",
    courseLevel: "Course Level",
    courseCapacity: "Course Capacity",
    enrollInCourse: "Enroll in Course",
    unenrollFromCourse: "Unenroll from Course",
    availableCourses: "Available Courses",
    myCourses: "My Courses",

    // Files
    uploadFile: "Upload File",
    selectFile: "Select File",
    fileUploaded: "File uploaded successfully",
    fileUploadError: "Error uploading file",
    maxFileSize: "Maximum file size",
    supportedFormats: "Supported formats",

    // Calendar
    calendar: "Calendar",
    today: "Today",
    month: "Month",
    week: "Week",
    day: "Day",

    // Errors
    error: "Error",
    pageNotFound: "Page Not Found",
    unauthorized: "Unauthorized",
    sessionExpired: "Session Expired",
    tryAgain: "Try Again",

    // Teacher
    teacherDashboard: "Teacher Dashboard",
    uploadClass: "Upload Class",
    assignTask: "Assign Task",
    registerAttendance: "Register Attendance",
    myClasses: "My Classes",
    taskReview: "Task Review",
    noClassesScheduled: "No classes scheduled.",
    noTasksToReview: "No tasks to review.",
  },
}

type Language = "es" | "en"
type TranslationKeys = keyof typeof translations.es

interface LanguageContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: TranslationKeys) => string
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("es")

  useEffect(() => {
    // Get language from localStorage if available
    const storedLanguage = localStorage.getItem("language") as Language
    if (storedLanguage && (storedLanguage === "es" || storedLanguage === "en")) {
      setLanguage(storedLanguage)
    }
  }, [])

  // Update localStorage when language changes
  useEffect(() => {
    localStorage.setItem("language", language)
  }, [language])

  // Translation function
  const t = (key: TranslationKeys): string => {
    return translations[language][key] || key
  }

  return <LanguageContext.Provider value={{ language, setLanguage, t }}>{children}</LanguageContext.Provider>
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}
