"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { onAuthStateChanged, signInWithEmailAndPassword, signOut } from "firebase/auth"
import { ref, get } from "firebase/database"
import { auth, database, firebaseInitialized } from "@/lib/firebase"

interface AuthUser {
  uid: string
  email: string | null
  role?: string
}

interface AuthContextType {
  user: AuthUser | null
  loading: boolean
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>
  logout: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Demo users for development mode
const demoUsers = [
  { email: "estudiante@example.com", password: "password123", role: "estudiante", uid: "demo-estudiante-1" },
  { email: "profesor@example.com", password: "password123", role: "profesor", uid: "demo-profesor-1" },
  { email: "admin@example.com", password: "password123", role: "admin", uid: "demo-admin-1" },
]

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check if we're in development mode (no Firebase)
    if (!firebaseInitialized) {
      console.log("Running in development mode without Firebase")
      const userStr = localStorage.getItem("user")
      if (userStr) {
        try {
          const userData = JSON.parse(userStr)
          setUser(userData)
        } catch (e) {
          setUser(null)
        }
      } else {
        setUser(null)
      }
      setLoading(false)
      return
    }

    // If Firebase is initialized, use onAuthStateChanged
    const unsubscribe = onAuthStateChanged(auth!, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          // Get user role from database
          const userRef = ref(database!, `users/${firebaseUser.uid}`)
          const snapshot = await get(userRef)
          const userData = snapshot.exists() ? snapshot.val() : {}

          const authUser: AuthUser = {
            uid: firebaseUser.uid,
            email: firebaseUser.email,
            role: userData.role || "estudiante", // Default role
          }

          setUser(authUser)
          // Save to localStorage as backup
          localStorage.setItem("user", JSON.stringify(authUser))
        } catch (error) {
          console.error("Error getting user data:", error)
          setUser({
            uid: firebaseUser.uid,
            email: firebaseUser.email,
          })
        }
      } else {
        setUser(null)
        localStorage.removeItem("user")
      }
      setLoading(false)
    })

    return () => unsubscribe()
  }, [])

  const login = async (email: string, password: string) => {
    try {
      // Check if we're in development mode (no Firebase)
      if (!firebaseInitialized) {
        console.log("Login in development mode")
        // Find demo user
        const demoUser = demoUsers.find(
          (user) => user.email.toLowerCase() === email.toLowerCase() && user.password === password,
        )

        if (demoUser) {
          const mockUser = {
            uid: demoUser.uid,
            email: demoUser.email,
            role: demoUser.role,
          }
          setUser(mockUser)
          localStorage.setItem("user", JSON.stringify(mockUser))
          return { success: true }
        } else {
          return {
            success: false,
            error: "Credenciales inválidas. En modo desarrollo, usa uno de los usuarios de demostración.",
          }
        }
      }

      // If Firebase is initialized, use signInWithEmailAndPassword
      const userCredential = await signInWithEmailAndPassword(auth!, email, password)
      const firebaseUser = userCredential.user

      // Get user role from database
      const userRef = ref(database!, `users/${firebaseUser.uid}`)
      const snapshot = await get(userRef)

      if (snapshot.exists()) {
        const userData = snapshot.val()
        const authUser: AuthUser = {
          uid: firebaseUser.uid,
          email: firebaseUser.email,
          role: userData.role || "estudiante", // Default role
        }
        setUser(authUser)
        localStorage.setItem("user", JSON.stringify(authUser))
      } else {
        // User doesn't exist in database
        setUser({
          uid: firebaseUser.uid,
          email: firebaseUser.email,
          role: "estudiante", // Default role
        })
      }

      return { success: true }
    } catch (error: any) {
      console.error("Login error:", error)
      return {
        success: false,
        error: error.message || "Error al iniciar sesión",
      }
    }
  }

  const logout = async () => {
    try {
      if (firebaseInitialized) {
        await signOut(auth!)
      }
      setUser(null)
      localStorage.removeItem("user")
    } catch (error) {
      console.error("Error signing out:", error)
    }
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        login,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
